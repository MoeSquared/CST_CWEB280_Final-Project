from pathlib import Path

SQL_CONNECTION_STRING = "sqlite:///CourseTracker.db"
ASSIGNMENT_UPLOAD_DIR = Path("./public/assignment_uploads")
COURSE_UPLOAD_DIR = Path("./public/course_uploads")
